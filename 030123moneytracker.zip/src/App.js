import React from 'react'
import './App.css';
import Title from './components/Title';
import Main from './components/Main';
import Breakdown from './components/Breakdown';
import Balance from './components/Balance';
import Qconvert from './components/Qconvert';
import Categories from './components/Categories';

function App() {
  return (
    <div className="App">
      <Title />
      <Qconvert />
      <Categories />
      <Main />
      <Breakdown />
    </div>
  );
}

export default App;
