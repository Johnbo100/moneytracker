import React from 'react'

function Title() {
  return (
    <div className='title'>Money Tracker</div>
  )
}

export default Title