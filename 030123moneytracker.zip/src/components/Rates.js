import React, { useState } from 'react'

export const Rates = () => {
 
const[rates,setRates]=useState()    
var myHeaders = new Headers();
myHeaders.append("apikey", "mlEw8jHEQ9Ezap95NWRuzAGMnfYeBT4U");

var requestOptions = {
  method: 'GET',
  redirect: 'follow',
  headers: myHeaders
};

const getrates = () =>{
fetch("https://api.apilayer.com/exchangerates_data/convert?to=thb&from=gbp&amount=1", requestOptions)
  .then(response => response.text())
  .then(result => console.table(result))
  .then(setRates(result=>(result)))
  .then(console.log("Rates in rates:::::::"+typeof(rates)))
  .catch(error => console.log('there is an error ::::::::', error));
    }


  return (
     <div>
        {/* <button onClick={getrates}>Get rates</button>
    // Rates */}
   
    
    </div>
  )
}
