import React, { useState } from 'react'

const Qconvert = () => {
    const[result,setResult]=useState(0)

  const convert = (mtype,val) =>{
    mtype ==="gbp" ? setResult(val * 42.33):setResult(val *.023)
  }
  return (
    <div className='qconvert'>
        <div>
            GBP<input type="number" onChange={(e) => {
     convert("gbp",e.target.value)
    }}/>
            BHT<input type="number" onChange={(e) => {
     convert("bht",e.target.value)
    }}/>
            {result}
        </div>
    </div>
  )
}

export default Qconvert