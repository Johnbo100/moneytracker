import React, { useState,useEffect} from 'react'
import axios from 'axios';
import { Rates } from './Rates';



function Main() {
  const[records,setRecords]=useState(null)
  const[spent,setSpent]=useState(0);
  const[day,setDay]=useState();
  const[status,setStatus]=useState('waiting')  
  const[cat,setCat]=useState('test')
  const[balance,setBalance]=useState([])
  const[newbalance,setNewbalance]=useState()
  const[category,setCategory]=useState([{}])
  const[exreport,setExreport]=useState([{}])
  const[gtotal,setGtotal]=useState(0)
  const[tdays,setTdays]=useState(0)

  

  useEffect(() => {
    getdata();
  },[spent]);

  useEffect(() => {
    getCat();
  },[]);

  useEffect(()=>{
      records !== null && setBalance(records[records.length-1])
      setNewbalance(balance.balance - spent)
      console.log(`current balance is:${balance}`)
    
  },[spent, records])

  function getdata() {
    axios.get('https://moneytrackerapi.acs-web.co.uk/').then((response) => {
      setRecords(response.data);
      console.table(response.data);
    }).catch(error => console.log(error));
  }
   
  function newexpense() {
    axios.post('https://moneytrackerapi.acs-web.co.uk/add',{ex:spent,date:day,cat:cat,bal:newbalance}).then((response) => {
       setStatus("new record added");
    }).catch(error => console.log("Error when posting new expense" +error));
  }

  function adjustbalance() {
    axios.post('https://moneytrackerapi.acs-web.co.uk/add',{ex:0,date:day,cat:"balance",bal:newbalance}).then((response) => {
      setStatus("new record added");
    }).catch(error => setStatus(error));
  }

  const getCat=()=>{
    axios.get('https://moneytrackerapi.acs-web.co.uk/cat').then((response)=>{
        setCategory(response.data);
    }).catch(error => console.log(error)) 
  }
  const handleChangeCat = event => {
    setCat(event.target.value);
    console.log('value is:', event.target.value);
  };  

  const report = () =>{
    var sum = 0;
    var prevdate = records[0].date;
    var lastid = records[records.length -1].id;
    var store = []
    var grandtotal = 0;
    var daycount =1;

    console.log("first date is :" + records[0].date)

    records.forEach(subData => {
      
      if(prevdate == subData.date){ 
        sum += subData.expense
        if(subData.id === lastid){
          store.push({date:prevdate,total:sum})
        }      
      }else{
        grandtotal += sum;
        daycount++;
        console.log("here is the grandtotal" + grandtotal +"--" + sum)
        store.push({date:prevdate,total:sum})
        prevdate = subData.date;
        console.log("date changed :"+prevdate)
        sum=0;
        sum += subData.expense
        
      }      
      
    }); 
    console.table(store)
    setExreport(store)
    setGtotal(grandtotal)
    setTdays(daycount)
  }

  return (
    <div>
        <Rates />
        <div className='spacered'>
          <label>Adjust bal:(THB)</label>
          <input onChange={(e)=>{setNewbalance(balance.balance + parseInt(e.target.value))}} type="number" />
          <button onClick={adjustbalance}>Change balance</button>
        </div>
        <div className='spent'>
          <div className='space'>
            <label>Spent(THB)</label>
            <input onChange={(e)=>{setSpent(e.target.value)}} type="number" />
          </div>
          <div className='space'>
            <label>Date</label>
            <input onChange={(e)=>{setDay(e.target.value)}} type="date" />
          </div>
          <div className='space'>
            <label>Category</label>
            <select name = 'category' onChange={handleChangeCat}>
                  <option>Select category</option>
                 {category.map((val,key)=>
                 <option>{val.catname}</option>)} 
              </select>  
          </div>
          <div className='space'>
            <label>Current balance</label>
            {balance.balance}
            <label>New balance</label>
            {newbalance}
          </div>

          <div className='space'>
              <button onClick={newexpense}>Add expenditure</button>
              {status}
          </div>
        </div>          
        <div>
            <button className='reportbtn' onClick={report}>Total expenses</button>
        </div>
        <div className='gtotal'> Grand total = baht:<span className='nums'>{gtotal}</span>gbp:<span className='nums'>{gtotal *0.023}</span>in <span className='nums'>{tdays}</span>days</div>
        <div className='gtotal'> Predicted 1 month:<span className='nums'>{gtotal / tdays *30}</span> gbp:<span className='nums'>{gtotal / tdays *30 *0.023}</span></div>
        <div className='gtotal'>Outcome 
        1m<span className='nums'>{8200 - 1 * 550}</span>
        2m<span className='nums'>{8200 - 2 * 550}</span>
        3m<span className='nums'>{8200 - 3 * 550}</span>
        4m<span className='nums'>{8200 - 4 * 550}</span>
        5m<span className='nums'>{8200 - 5 * 550}</span>
        6m<span className='nums'>{8200 - 6 * 550}</span>
        </div>
        {exreport.map((s) => {
          return (
            <div className='exreport'>
              Date<input placeholder={s.date}/>
              BHT<input placeholder={s.total}/> 
              GBP<input placeholder={s.total * 0.023}/>
            </div>     
          );
        })}
        
        {records !== null && records.map((s) => {
          return (
            <div className='breakdown'>
              Date<input placeholder={s.date}/>
              B<input placeholder={s.expense}/>
              {'\u00A3'}<input placeholder={s.expense * 0.023}/>
              <input placeholder={s.category}/>
              Bl<input placeholder={s.balance}/>
              
            </div>     

          );
        })}
        
        <div className='space'>
        

        </div>
    </div>
  )
}

export default Main